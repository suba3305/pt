<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Care Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

      /* Navigation Styling */
      nav {
            background-color: #2d3e50;
            padding: 16px 0;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color:rgb(148, 110, 48);
        }

        /* Logo Styling */
        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        /* Dropdown Menu Styling */
        .dropdown {
            display: inline-block;
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #2d3e50;
            min-width: 160px;
            z-index: 1;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .dropdown-content a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-content a:hover {
            background-color: #f39c12;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Grid Layout for Pet Care Products */
        .container {
            width: 80%;
            margin: 40px auto;
            text-align: center;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 columns */
            gap: 20px;
            margin-top: 20px;
        }

        .product-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            text-align: center;
            padding: 20px;
        }

        .product-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
        }

        .product-card h2 {
            margin: 10px 0;
            color: #333;
        }

        .product-card p {
            color: #777;
            padding: 0 15px;
        }

        .price {
            font-size: 20px;
            color: #2d3e50;
            font-weight: bold;
        }

        .buy-button {
            background-color: #2d3e50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        .buy-button:hover {
            background-color: #a77628;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav>
    <!-- Logo -->
    <a href="index.php" class="logo">Paw Finder</a>
    
    <!-- Dropdown Menu for Pets List -->
    <div class="dropdown">
        <a href="#">Pets List</a>
        <div class="dropdown-content">
            <a href="dogs.php">Dogs</a>
            <a href="cats.php">Cats</a>
            <a href="other_pets.php">Other Pets</a>
        </div>
    </div>

    <!-- Other Navigation Links -->
    <a href="pet_tips.php">Pet Tips</a>
    <a href="rescued_pets.php">Rescued Pets</a>
    <a href="adopt_now.php">Adopt Now</a>
    <a href="pet_care.php">Pet Care</a>
    <a href="feedback.php">Feedback</a>
</nav>
<!-- Pet Care Products Section -->
<div class="container">
    <h1>Shop for Pet Care Products</h1>
    <div class="grid">
        <?php
        // Example products array (replace with real data or database)
        $products = [
            [
                "name" => "Dog Shampoo",
                "image" => "img/dog_shampoo.jpg",
                "description" => "Gentle shampoo for your furry friend.",
                "price" => "$10.99"
            ],
            [
                "name" => "Cat Litter",
                "image" => "img/cat_litter.jpg",
                "description" => "Premium quality litter for your cats.",
                "price" => "$12.99"
            ],
            [
                "name" => "Pet Collar",
                "image" => "img/pet_collar.jpg",
                "description" => "Durable collar for your pet's safety.",
                "price" => "$8.99"
            ],
            [
                "name" => "Pet Brush",
                "image" => "img/pet_brush.jpg",
                "description" => "High-quality brush for smooth fur.",
                "price" => "$15.49"
            ],
            [
                "name" => "Pet Food",
                "image" => "img/pet_food.jpg",
                "description" => "Healthy and nutritious food for your pet.",
                "price" => "$20.99"
            ],
            [
                "name" => "Pet Bed",
                "image" => "img/pet_bed.jpg",
                "description" => "Comfortable bed for your pet to rest.",
                "price" => "$25.99"
            ],
            [
                "name" => "Pet Toy",
                "image" => "img/pet_toy.jpg",
                "description" => "Fun toy to keep your pet entertained.",
                "price" => "$5.99"
            ],
            [
                "name" => "Pet Water Bottle",
                "image" => "img/pet_water_bottle.jpg",
                "description" => "Portable water bottle for outdoor activities.",
                "price" => "$6.49"
            ],
            [
                "name" => "Pet First Aid Kit",
                "image" => "img/pet_first_aid.jpg",
                "description" => "Complete first aid kit for emergencies.",
                "price" => "$18.99"
            ]
        ];

        // Loop through products and display them
        foreach ($products as $product) {
            echo '<div class="product-card">';
            echo '<img src="' . $product['image'] . '" alt="' . $product['name'] . '">';
            echo '<h2>' . $product['name'] . '</h2>';
            echo '<p>' . $product['description'] . '</p>';
            echo '<p class="price">' . $product['price'] . '</p>';
            echo '<button class="buy-button">Buy Now</button>';
            echo '</div>';
        }
        ?>
    </div>
</div>

</body>
</html>
