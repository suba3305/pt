<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Tips | Paw Finder</title>
    <style>
        /* General reset and body styling */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #fafafa;
            color: #333;
        }

        /* Navigation Styling */
        nav {
            background-color: #2d3e50;
            padding: 16px 0;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color:rgb(148, 110, 48);
        }

        /* Logo Styling */
        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        /* Dropdown Menu Styling */
        .dropdown {
            display: inline-block;
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #2d3e50;
            min-width: 160px;
            z-index: 1;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .dropdown-content a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-content a:hover {
            background-color: #f39c12;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Container for content */
        .container {
            width: 85%;
            margin: 0 auto;
            padding-top: 40px;
        }

        h1 {
            text-align: center;
            font-size: 36px;
            margin-bottom: 20px;
            color: #333;
            font-weight: 700;
        }

        /* Tips Section Styling */
        .tips-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 40px;
            margin-top: 40px;
        }

        .tip-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .tip-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }

        .tip-card h2 {
            font-size: 24px;
            margin-bottom: 15px;
            color: #2d3e50;
            font-weight: 600;
        }

        .tip-card ul {
            list-style: none;
            padding-left: 0;
        }

        .tip-card ul li {
            font-size: 16px;
            color: #666;
            line-height: 1.6;
            position: relative;
            padding-left: 25px;
        }

        .tip-card ul li::before {
            content: "✔";
            color: #f39c12;
            position: absolute;
            left: 0;
            top: 0;
            font-size: 18px;
        }

        /* Button styling */
        .tip-button {
            background-color: #f39c12;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            margin-top: 20px;
            transition: background-color 0.3s;
        }

        .tip-button:hover {
            background-color: #e67e22;
        }

        /* Footer */
        footer {
            background-color: #2d3e50;
            color: white;
            padding: 30px 0;
            text-align: center;
            margin-top: 60px;
        }

        footer p {
            font-size: 14px;
        }

    </style>
</head>
<body>
   <!-- Navigation Bar -->
<nav>
    <!-- Logo -->
    <a href="index.php" class="logo">Paw Finder</a>
    
    <!-- Dropdown Menu for Pets List -->
    <div class="dropdown">
        <a href="#">Pets List</a>
        <div class="dropdown-content">
            <a href="dogs.php">Dogs</a>
            <a href="cats.php">Cats</a>
            <a href="other_pets.php">Other Pets</a>
        </div>
    </div>

    <!-- Other Navigation Links -->
    <a href="pet_tips.php">Pet Tips</a>
    <a href="rescued_pets.php">Rescued Pets</a>
    <a href="adopt_now.php">Adopt Now</a>
    <a href="pet_care.php">Pet Care</a>
    <a href="feedback.php">Feedback</a>
</nav>




    <!-- Main Content Area -->
    <div class="container">
        <h1>Helpful Pet Tips for Loving Pet Parents</h1>

        <!-- Tips Section -->
        <div class="tips-section">
            <!-- Health Tips -->
            <div class="tip-card">
                <h2>Health Tips</h2>
                <ul>
                    <li>Ensure your pet gets a regular checkup with the vet.</li>
                    <li>Monitor your pet’s weight to avoid obesity-related health issues.</li>
                    <li>Provide a balanced diet suited for their age and breed.</li>
                    <li>Hydration is crucial—always ensure access to fresh water.</li>
                    <li>Prevent dental issues by brushing your pet's teeth regularly.</li>
                </ul>
                <button class="tip-button">Learn More</button>
            </div>

            <!-- Vaccination Tips -->
            <div class="tip-card">
                <h2>Vaccination Tips</h2>
                <ul>
                    <li>Consult your vet about essential vaccinations for your pet.</li>
                    <li>Keep track of booster shots to ensure immunity is maintained.</li>
                    <li>Ask about any optional vaccines, especially for travel or exposure to other animals.</li>
                    <li>Establish a vaccination schedule with your vet from a young age.</li>
                    <li>Keep a vaccination record for reference and emergencies.</li>
                </ul>
                <button class="tip-button">Learn More</button>
            </div>

            <!-- Physical Care Tips -->
            <div class="tip-card">
                <h2>Physical Care Tips</h2>
                <ul>
                    <li>Groom your pet regularly to maintain healthy skin and fur.</li>
                    <li>Trim nails, clean ears, and brush teeth for overall well-being.</li>
                    <li>Provide safe outdoor activities like walks and playtime to keep them active.</li>
                    <li>Offer your pet a cozy space for rest, away from distractions.</li>
                    <li>Protect your pet from extreme weather conditions with proper clothing and shelter.</li>
                </ul>
                <button class="tip-button">Learn More</button>
            </div>
        </div>

        <!-- Extra Tips for Well-Trained Pet Parents -->
        <div class="tip-card">
            <h2>Extra Tips for Well-Trained Pet Parents</h2>
            <ul>
                <li>Consistency is key—establish a daily routine and stick to it.</li>
                <li>Use positive reinforcement to encourage good behavior.</li>
                <li>Socialize your pet with other animals and people to build confidence.</li>
                <li>Invest in professional training if needed, especially for puppies or rescue pets.</li>
                <li>Patience and understanding are essential—training takes time.</li>
                <li>Offer mental stimulation through puzzles, games, and interactive toys.</li>
            </ul>
            <button class="tip-button">Learn More</button>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Paw Finder. All Rights Reserved.</p>
    </footer>

</body>
</html>
