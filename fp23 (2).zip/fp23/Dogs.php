<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dog Adoption</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        /* Navigation Styling */
        nav {
            background-color: #2d3e50;
            padding: 16px 0;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #a77628;
        }

        /* Logo Styling */
        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        /* Dropdown Menu Styling */
        .dropdown {
            display: inline-block;
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #2d3e50;
            min-width: 160px;
            z-index: 1;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .dropdown-content a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-content a:hover {
            background-color: #f39c12;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }
        .container {
            width: 90%;
            margin: 20px auto;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 columns */
            gap: 20px;
            margin-top: 20px;
        }

        .dog-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            text-align: center;
        }

        .dog-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .dog-card h2 {
            margin: 10px 0;
            color: #555;
        }

        .dog-card p {
            color: #777;
            padding: 0 15px;
        }

        .adopt-button {
            background-color: rgb(1, 20, 1);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 15px;
        }

        .adopt-button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
<nav>
    <!-- Logo -->
    <a href="index.php" class="logo">Paw Finder</a>
    
    <!-- Dropdown Menu for Pets List -->
    <div class="dropdown">
        <a href="#">Pets List</a>
        <div class="dropdown-content">
            <a href="dogs.php">Dogs</a>
            <a href="cats.php">Cats</a>
            <a href="other_pets.php">Other Pets</a>
        </div>
    </div>

    <!-- Other Navigation Links -->
    <a href="pet_tips.php">Pet Tips</a>
    <a href="rescued_pets.php">Rescued Pets</a>
    <a href="adopt_now.php">Adopt Now</a>
    <a href="pet_care.php">Pet Care</a>
    <a href="feedback.php">Feedback</a>
</nav>

    <div class="container">
        <h1>Adopt a Dog Today!</h1>
        <div class="grid">
            <?php
            $dogs = [
                [
                    "name" => "Labrador Retriever",
                    "image" => "img/lab.jpg",  // Ensure the image exists
                    "description" => "Friendly, active, and outgoing."
                ],
                [
                    "name" => "Golden Retriever",
                    "image" => "img/gr.jpg",
                    "description" => "Intelligent, friendly, and devoted."
                ],
                [
                    "name" => "German Shepherd",
                    "image" => "img/gs.jpeg",
                    "description" => "Confident, courageous, and intelligent."
                ],
                [
                    "name" => "Beagle",
                    "image" => "img/bg.jpg",
                    "description" => "Curious, friendly, and merry."
                ],
                [
                    "name" => "Bulldog",
                    "image" => "img/bull.JPEG",
                    "description" => "Calm, courageous, and affectionate."
                ],
                [
                    "name" => "Poodle",
                    "image" => "img/pl.jpg",
                    "description" => "Intelligent, elegant, and playful."
                ],
                [
                    "name" => "Boxer",
                    "image" => "img/bx3.jpg",
                    "description" => "Energetic, loyal, and fun-loving."
                ],
                [
                    "name" => "Dachshund",
                    "image" => "img/dd.jpg",
                    "description" => "Curious, brave, and lively."
                ],
                [
                    "name" => "Chihuahua",
                    "image" => "img/cn.jpeg",
                    "description" => "Loyal, alert, and charming."
                ]
            ];

            foreach ($dogs as $dog) {
                echo '<div class="dog-card">';
                echo '<img src="' . $dog['image'] . '" alt="' . $dog['name'] . '">';
                echo '<h2>' . $dog['name'] . '</h2>';
                echo '<p>' . $dog['description'] . '</p>';
                echo '<button class="adopt-button">Adopt Now</button>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</body>
</html>
