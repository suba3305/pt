<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paw Finder</title>
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body and Font */
        body {
            font-family: Arial, sans-serif;
            background: url(img/h2.JPEG) no-repeat center center fixed; /* Set the background image */
            background-size: cover; /* Ensure the image covers the whole page */
            color: white;
        }

      /* Navigation Styling */
      nav {
            background-color: #2d3e50;
            padding: 16px 0;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #a77628;
        }

        /* Logo Styling */
        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        /* Dropdown Menu Styling */
        .dropdown {
            display: inline-block;
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #2d3e50;
            min-width: 160px;
            z-index: 1;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .dropdown-content a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-content a:hover {
            background-color: #f39c12;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Content Section */
        .content {
            padding: 250px;
        }

        .content h2 {
            color: white;
            margin-bottom: 10px;
        }

        
    </style>
</head>
<body>
    <!-- Navigation Bar -->
<nav>
    <!-- Logo -->
    <a href="index.php" class="logo">Paw Finder</a>
    
    <!-- Dropdown Menu for Pets List -->
    <div class="dropdown">
        <a href="#">Pets List</a>
        <div class="dropdown-content">
            <a href="dogs.php">Dogs</a>
            <a href="cats.php">Cats</a>
            <a href="other_pets.php">Other Pets</a>
        </div>
    </div>

    <!-- Other Navigation Links -->
    <a href="pet_tips.php">Pet Tips</a>
    <a href="rescued_pets.php">Rescued Pets</a>
    <a href="adopt_now.php">Adopt Now</a>
    <a href="pet_care.php">Pet Care</a>
    <a href="feedback.php">Feedback</a>
</nav>


     
    <!-- Home Page Content -->
    <div class="content">
        <center>
        <h2>Welcome to Paw Finder</h2>
   
        
        </center>



    
</body>
</html>
