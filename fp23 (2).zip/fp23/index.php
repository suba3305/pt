<?php
// Start session to manage login state
session_start();

// Database connection variables
$servername = "localhost";  // Change to your server
$username = "root";         // Change to your DB username
$password = "";             // Change to your DB password
$dbname = "paw_finder";     // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $input_username = $_POST['username'];
    $input_password = $_POST['password'];
    $role = $_POST['role'];

    // Prepare query to find the user with the provided credentials
    $sql = "SELECT * FROM users WHERE username = ? AND role = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $input_username, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if user exists
    if ($result->num_rows > 0) {
        // Fetch user data
        $user = $result->fetch_assoc();
        
        // Verify the password using password_verify()
        if (password_verify($input_password, $user['password'])) {
            // If login is successful, set session variables
            $_SESSION['logged_in'] = true;
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            // Redirect based on role (Admin or User)
            if ($user['role'] === 'admin') {
                header("Location: admin_dashboard.php"); // Admin dashboard
            } else {
                header("Location: user_dashboard.php");  // User dashboard
            }
            exit();
        } else {
            // Invalid password
            $error_message = "Invalid password!";
        }
    } else {
        // Invalid username or role
        $error_message = "Invalid username or role!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Paw Finder</title>
    <style>
        /* Internal CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: url('img/h2.JPEG') no-repeat center center fixed;
            background-size: cover;
            color: white;
            text-align: center;
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            margin: 100px auto;
            padding: 30px;
            background-color: rgba(0, 0, 0, 0.6);
            border-radius: 8px;
        }

        .login-container h2 {
            margin-bottom: 20px;
        }

        .login-container input, .login-container select {
            width: 80%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: none;
            font-size: 16px;
        }

        .login-container input[type="submit"] {
            background-color: #f39c12;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .login-container input[type="submit"]:hover {
            background-color: #a77628;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <div class="login-container">
        <h2>Login</h2>
        
        <!-- Display error message if login fails -->
        <?php if (isset($error_message)): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>
        
        <!-- Login Form -->
        <form action="login.php" method="POST">
            <input type="text" name="username" placeholder="Username" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            
            <!-- Role selection (Admin/User) -->
            <select name="role" required>
                <option value="" disabled selected>Select Role</option>
                <option value="admin">Admin</option>
                <option value="user">User</option>
            </select><br>
            
            <input type="submit" value="Login">
        </form>
    </div>

</body>
</html>
