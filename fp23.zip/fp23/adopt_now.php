<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Adoption Form for Rescued Pets</title>
    <style>
        /* Basic styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

       /* Navigation Styling */
       nav {
            background-color: #2d3e50;
            padding: 16px 0;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color:rgb(148, 110, 48);
        }

        /* Logo Styling */
        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        /* Dropdown Menu Styling */
        .dropdown {
            display: inline-block;
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #2d3e50;
            min-width: 160px;
            z-index: 1;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .dropdown-content a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-content a:hover {
            background-color: #f39c12;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }


        /* Form Styling */
        .form-container {
            width: 80%;
            max-width: 600px;
            margin: 40px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            text-align: center;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        .form-group textarea {
            resize: vertical;
            height: 150px;
        }

        .form-group button {
            padding: 12px 20px;
            background-color: #2d3e50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        .form-group button:hover {
            background-color: #a77628;
        }

        .form-group .required {
            color: red;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav>
    <!-- Logo -->
    <a href="index.php" class="logo">Paw Finder</a>
    
    <!-- Dropdown Menu for Pets List -->
    <div class="dropdown">
        <a href="#">Pets List</a>
        <div class="dropdown-content">
            <a href="dogs.php">Dogs</a>
            <a href="cats.php">Cats</a>
            <a href="other_pets.php">Other Pets</a>
        </div>
    </div>

    <!-- Other Navigation Links -->
    <a href="pet_tips.php">Pet Tips</a>
    <a href="rescued_pets.php">Rescued Pets</a>
    <a href="adopt_now.php">Adopt Now</a>
    <a href="pet_care.php">Pet Care</a>
    <a href="feedback.php">Feedback</a>
</nav>


<!-- Pet Adoption Form for Rescued Pets -->
<div class="form-container">
    <h1>Adopt a Rescued Pet</h1>
    <p>Please fill in the form below to adopt a rescued pet.</p>

    <form method="post" action="process_adoption.php">
        <!-- Full Name -->
        <div class="form-group">
            <label for="full_name">Full Name <span class="required">*</span></label>
            <input type="text" id="full_name" name="full_name" required>
        </div>

        <!-- Email Address -->
        <div class="form-group">
            <label for="email">Email Address <span class="required">*</span></label>
            <input type="email" id="email" name="email" required>
        </div>

        <!-- Phone Number -->
        <div class="form-group">
            <label for="phone">Phone Number <span class="required">*</span></label>
            <input type="text" id="phone" name="phone" required>
        </div>

        <!-- Address -->
        <div class="form-group">
            <label for="address">Address <span class="required">*</span></label>
            <textarea id="address" name="address" required></textarea>
        </div>

        <!-- Living Situation -->
        <div class="form-group">
            <label for="home_type">Do you live in a house, apartment, or other? <span class="required">*</span></label>
            <input type="text" id="home_type" name="home_type" required>
        </div>

        <!-- Yard or Space for Active Pet -->
        <div class="form-group">
            <label for="yard_space">Do you have a yard or space for an active pet? <span class="required">*</span></label>
            <select id="yard_space" name="yard_space" required>
                <option value="yes">Yes</option>
                <option value="no">No</option>
            </select>
        </div>

        <!-- Have you adopted a pet before? -->
        <div class="form-group">
            <label for="adopted_before">Have you adopted a pet before? <span class="required">*</span></label>
            <select id="adopted_before" name="adopted_before" required>
                <option value="yes">Yes</option>
                <option value="no">No</option>
            </select>
        </div>

        <!-- Special Needs or Behavioral Care -->
        <div class="form-group">
            <label for="special_needs_experience">Have you ever taken care of a pet with special needs or behavioral issues? <span class="required">*</span></label>
            <select id="special_needs_experience" name="special_needs_experience" required>
                <option value="yes">Yes</option>
                <option value="no">No</option>
            </select>
        </div>

        <!-- Extra Care and Training for Rescued Pets -->
        <div class="form-group">
            <label for="extra_care">Are you prepared to provide extra care, training, and attention to a rescued pet? <span class="required">*</span></label>
            <select id="extra_care" name="extra_care" required>
                <option value="yes">Yes</option>
                <option value="no">No</option>
            </select>
        </div>

        <!-- Awareness of Medical Needs -->
        <div class="form-group">
            <label for="medical_needs_awareness">Are you aware that rescued pets may have medical needs and could need ongoing treatment? <span class="required">*</span></label>
            <select id="medical_needs_awareness" name="medical_needs_awareness" required>
                <option value="yes">Yes</option>
                <option value="no">No</option>
            </select>
        </div>

        <!-- Emergency Contact and Preparedness -->
        <div class="form-group">
            <label for="emergency_contact">Emergency Contact Name</label>
            <input type="text" id="emergency_contact" name="emergency_contact">
        </div>

        <div class="form-group">
            <label for="emergency_preparedness">In case of an emergency, are you prepared to transport your pet to the vet or a care center immediately? <span class="required">*</span></label>
            <select id="emergency_preparedness" name="emergency_preparedness" required>
                <option value="yes">Yes</option>
                <option value="no">No</option>
            </select>
        </div>

        <!-- Adoption Reason -->
        <div class="form-group">
            <label for="adopt_reason">Why do you want to adopt a rescued pet? <span class="required">*</span></label>
            <textarea id="adopt_reason" name="adopt_reason" required></textarea>
        </div>

        <!-- Submit Button -->
        <div class="form-group">
            <button type="submit">Submit Adoption Request</button>
        </div>
    </form>
</div>

</body>
</html>
