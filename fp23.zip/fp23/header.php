<!-- header.php -->
<header>
    <h1>Welcome to Pet Adoption</h1>
    <p>Your perfect pet is just a click away</p>
</header>

<nav>
    <a href="index.php">Home</a>
    <a href="pet-tips.php">Pet Tips</a>
    <a href="rescued-pets.php">Rescued Pets</a>
    <a href="adopt-now.php">Adopt Now</a>
    <a href="pet-care.php">Pet Care</a>
    <a href="pet-products.php">Pet Products</a>
    <a href="feedback.php">Feedback</a>
</nav>
