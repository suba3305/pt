<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Other Pets Adoption</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        /* Navigation Bar */
        nav {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            padding: 10px 15px;
            display: inline-block;
        }

        nav a:hover {
            background-color: #555;
        }

        /* Dropdown Menu */
        .dropdown {
            display: inline-block;
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #333;
            min-width: 160px;
            z-index: 1;
        }

        .dropdown-content a {
            color: white;
            padding: 10px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #555;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Logo */
        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }

        .container {
            width: 90%;
            margin: 20px auto;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 columns */
            gap: 20px;
            margin-top: 20px;
        }

        .pet-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            text-align: center;
        }

        .pet-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .pet-card h2 {
            margin: 10px 0;
            color: #555;
        }

        .pet-card p {
            color: #777;
            padding: 0 15px;
        }

        .adopt-button {
            background-color: rgb(1, 20, 1);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 15px;
        }

        .adopt-button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <a href="index.php" class="logo">Paw Finder</a>
        <div class="dropdown">
            <a href="#">Pets List</a>
            <div class="dropdown-content">
                <a href="dogs.php">Dogs</a>
                <a href="cats.php">Cats</a>
                <a href="other_pets.php">Other Pets</a>
            </div>
        </div>
        <a href="pet_tips.php">Pet Tips</a>
        <a href="rescued_pets.php">Rescued Pets</a>
        <a href="adopt_now.php">Adopt Now</a>
        <a href="pet_care.php">Pet Care</a>
        <a href="feedback.php">Feedback</a>
    </nav>

    <div class="container">
        <h1>Adopt an Other Pet Today!</h1>
        <div class="grid">
            <?php
            $other_pets = [
                [
                    "name" => "Rabbit",
                    "image" => "img/rabbit.jpg",  // Ensure the image exists
                    "description" => "Playful, social, and gentle."
                ],
                [
                    "name" => "Parrot",
                    "image" => "img/parrot.jpg",
                    "description" => "Colorful, talkative, and intelligent."
                ],
                [
                    "name" => "Guinea Pig",
                    "image" => "img/guinea_pig.jpg",
                    "description" => "Loving, friendly, and easy to handle."
                ],
                [
                    "name" => "Hamster",
                    "image" => "img/hamster.jpg",
                    "description" => "Curious, active, and low-maintenance."
                ],
                [
                    "name" => "Turtle",
                    "image" => "img/turtle.jpg",
                    "description" => "Slow-moving, peaceful, and long-lived."
                ],
                [
                    "name" => "Chinchilla",
                    "image" => "img/chinchilla.jpg",
                    "description" => "Soft, active, and nocturnal."
                ],
                [
                    "name" => "Ferret",
                    "image" => "img/ferret.jpg",
                    "description" => "Curious, playful, and friendly."
                ],
                [
                    "name" => "Sugar Glider",
                    "image" => "img/sugar_glider.jpg",
                    "description" => "Small, nocturnal, and sociable."
                ],
                [
                    "name" => "Bird",
                    "image" => "img/bird.jpg",
                    "description" => "Bright, vocal, and entertaining."
                ]
            ];

            foreach ($other_pets as $pet) {
                echo '<div class="pet-card">';
                echo '<img src="' . $pet['image'] . '" alt="' . $pet['name'] . '">';
                echo '<h2>' . $pet['name'] . '</h2>';
                echo '<p>' . $pet['description'] . '</p>';
                echo '<button class="adopt-button">Adopt Now</button>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</body>
</html>
