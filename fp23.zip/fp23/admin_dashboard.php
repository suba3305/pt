<?php
// admin_dashboard.php
session_start();

// Check if the user is logged in and has the role 'admin'
if (!isset($_SESSION['logged_in']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

echo "Welcome, Admin! <br>";
echo "Here is the Admin Dashboard.";
?>
