<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cat Adoption</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        /* Navigation Styling */
        nav {
            background-color: #2d3e50;
            padding: 16px 0;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #a77628;
        }

        /* Logo Styling */
        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        /* Dropdown Menu Styling */
        .dropdown {
            display: inline-block;
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #2d3e50;
            min-width: 160px;
            z-index: 1;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .dropdown-content a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-content a:hover {
            background-color: #f39c12;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .container {
            width: 90%;
            margin: 20px auto;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 columns */
            gap: 20px;
            margin-top: 20px;
        }

        .cat-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            text-align: center;
        }

        .cat-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .cat-card h2 {
            margin: 10px 0;
            color: #555;
        }

        .cat-card p {
            color: #777;
            padding: 0 15px;
        }

        .adopt-button {
            background-color: rgb(1, 20, 1);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 15px;
        }

        .adopt-button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
   <!-- Navigation Bar -->
<nav>
    <!-- Logo -->
    <a href="index.php" class="logo">Paw Finder</a>
    
    <!-- Dropdown Menu for Pets List -->
    <div class="dropdown">
        <a href="#">Pets List</a>
        <div class="dropdown-content">
            <a href="dogs.php">Dogs</a>
            <a href="cats.php">Cats</a>
            <a href="other_pets.php">Other Pets</a>
        </div>
    </div>

    <!-- Other Navigation Links -->
    <a href="pet_tips.php">Pet Tips</a>
    <a href="rescued_pets.php">Rescued Pets</a>
    <a href="adopt_now.php">Adopt Now</a>
    <a href="pet_care.php">Pet Care</a>
    <a href="feedback.php">Feedback</a>
</nav>

    <div class="container">
        <h1>Adopt a Cat Today!</h1>
        <div class="grid">
            <?php
            $cats = [
                [
                    "name" => "Persian Cat",
                    "image" => "img/pc.jpg",  // Ensure the image exists
                    "description" => "Gentle, affectionate, and calm."
                ],
                [
                    "name" => "Siamese Cat",
                    "image" => "img/ss.webp",
                    "description" => "Social, talkative, and playful."
                ],
                [
                    "name" => "Maine Coon",
                    "image" => "img/mc.jpg",
                    "description" => "Large, friendly, and loyal."
                ],
                [
                    "name" => "Bengal Cat",
                    "image" => "img/bc.jpeg",
                    "description" => "Active, curious, and energetic."
                ],
                [
                    "name" => "Ragdoll Cat",
                    "image" => "img/rd.jpg",
                    "description" => "Loving, gentle, and calm."
                ],
                [
                    "name" => "British Shorthair",
                    "image" => "img/bs.jpeg",
                    "description" => "Calm, easygoing, and affectionate."
                ],
                [
                    "name" => "Scottish Fold",
                    "image" => "img/sf.jpeg",
                    "description" => "Quiet, sweet, and loves attention."
                ],
                [
                    "name" => "Abyssinian Cat",
                    "image" => "img/ac.jfif",
                    "description" => "Curious, active, and playful."
                ],
                [
                    "name" => "Sphynx Cat",
                    "image" => "img/sp.jpg",
                    "description" => "Affectionate, energetic, and friendly."
                ]
            ];

            foreach ($cats as $cat) {
                echo '<div class="cat-card">';
                echo '<img src="' . $cat['image'] . '" alt="' . $cat['name'] . '">';
                echo '<h2>' . $cat['name'] . '</h2>';
                echo '<p>' . $cat['description'] . '</p>';
                echo '<button class="adopt-button">Adopt Now</button>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</body>
</html>
