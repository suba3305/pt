<?php
// user_dashboard.php
session_start();

// Check if the user is logged in and has the role 'user'
if (!isset($_SESSION['logged_in']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

echo "Welcome, User! <br>";
echo "Here is the User Dashboard.";
?>
